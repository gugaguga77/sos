﻿using Data;
using Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public class ProductService : IProductService
    {
        private readonly AppDbContext _contextDb;

        public ProductService(AppDbContext context)
        {
            _contextDb = context;
        }

        public async Task<Product> AddOneProduct(Product product)
        {
            await this._contextDb.AddAsync(product);
            await this._contextDb.SaveChangesAsync();
            return product;
        }

        public Product DeleteProduct(int id)
        {
            var product =  _contextDb.products.Find(id);
            if (product != null)
            {
                _contextDb.products.Remove(product);
                _contextDb.SaveChangesAsync();
                return product;
            }
            else
            {
                throw new Exception("prod is not found");
            }

        }

        public async Task<List<Product>> GetAllProduct()
        {
            return await _contextDb.products.ToListAsync();
        }



        public async Task<Product> GetProductbyID(int id)
        {
            return await _contextDb.products.FindAsync(id);
        }

        public async Task<List<Product>> RetriveProductsByCategory(int categoryID)
        {
            return await _contextDb.products.Where(p => p.CategoryId == categoryID).ToListAsync();
        }



        // Retrieve the total price of products in a specific category
        public async Task<decimal> RetriveTotalPriceByCategory(int categoryID)
        {
            return await _contextDb.products.Where(p => p.CategoryId == categoryID).SumAsync(p => p.Price);
        }



        public async Task<List<decimal>> RetriveTotalPriceOfProductPerCategory()
        {
            return await _contextDb.products.GroupBy(x => x.CategoryId).Select(p => p.Sum(n => n.Price)).ToListAsync();
        }


        public Product UpdateOneProduct(int id, Product product)
        {
            var prod = this._contextDb.products.FirstOrDefault(p => p.Id == id);
            if (prod != null)
            {
                prod.Price = product.Price;
                prod.Name = product.Name;
                _contextDb.SaveChanges();
                return prod;
            }
            else
            {
                throw new Exception("prod is not found");
            }
        }

    }
}
